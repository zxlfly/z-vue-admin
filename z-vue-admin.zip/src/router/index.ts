import { createRouter, createWebHistory } from "vue-router";
import { staticRoutes } from "./static-routes";
import dynamicRoutes from "./modules/index";

const router = createRouter({
	history: createWebHistory(import.meta.env.BASE_URL),
	routes: [
		...staticRoutes,
		{
			path: "/",
			name: "home",
			component: () => import("@/layout/index.vue"),
			children: [...dynamicRoutes],
		},
	],
});

export default router;
