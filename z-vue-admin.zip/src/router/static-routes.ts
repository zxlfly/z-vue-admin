import type { RouteRecordRaw } from "vue-router";

export const staticRoutes: RouteRecordRaw[] = [
	{
		path: "/login",
		name: "login",
		component: () => import("@/views/login/index.vue"),
		meta: {
			isWhite: true,
		},
	},
	// {
	// 	path: "/:pathMatch(.*)",
	// 	name: "NotFound",
	// 	component: () => import("@/views/404.vue"),
	// },
];
