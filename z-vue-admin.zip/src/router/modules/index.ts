import type { RouteRecordRaw } from "vue-router";

const modules = import.meta.glob("./routes/*.ts", { eager: true });
const appRoutes: RouteRecordRaw[] = [];
console.log("modules", modules);
// 加入到路由集合中
Object.keys(modules).forEach((key) => {
	const defaultModule = modules[key].default;
	if (!defaultModule) return;
	const moduleList = Array.isArray(defaultModule)
		? [...defaultModule]
		: [defaultModule];
	appRoutes.push(...moduleList);
});
console.log("appRoutes", appRoutes);
const dynamicRoutes: RouteRecordRaw[] = [
	{
		path: "dashboard",
		name: "dashboard",
		component: () => import("@/views/dashboard/index.vue"),
		children: [
			{
				path: "404",
				name: "404",
				component: () => import("@/views/404.vue"),
			},
		],
	},
	{
		path: "404",
		name: "404",
		component: () => import("@/views/404.vue"),
	},
];
export default dynamicRoutes;
